<?php
session_start();
if(empty($_SESSION['username'])){
    header("location:index.php?pesan=belum_login");
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Welcome</title>
    <link rel="stylesheet" href="css/bootstrap.min.css"
          integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/style.css" type="text/css">
    <link href="https://fonts.googleapis.com/css?family=Roboto&display=swap" rel="stylesheet">

</head>
<body>

<h5>Selamat Datang <?php echo $_SESSION['username']?>!</h5>

<!-- <div class="container"> -->
    <div class="card" id="header" style="height: 10%;padding-top: 20px;">
        <div class="card-body">
                <h1>Header</h1>
        </div>
    </div>
    <div class="card" id="sidebar" style="float: left;height: 400px;width: 18%;padding-top: 20px">
        <div class="card-body">

        </div>
    </div>
    <div class="card" id="content" style="float: left;height: 400px;width: 82%;padding-top: 20px">
        <div class="card-body">

        </div>
    </div>
    <div class="card" id="footer" style="height: 2%;width: 100%;padding-top: 20px">
        <div class="card-body">
        </div>
    </div>
<!-- </div> -->

<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js"
        integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN"
        crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js"
        integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q"
        crossorigin="anonymous"></script>
<script src="js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl"
        crossorigin="anonymous"></script>
</body>
</html>